﻿

namespace ValidandoSalario1.Entities.Enums
{
    enum WorkerLevel : int
    {
        Junior = 0,
        MidLevel = 1,
        Senior = 2
    }
}
