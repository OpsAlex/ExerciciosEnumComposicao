﻿using System;
using System.Collections.Generic;
using System.Text;
using ValidandoSalario1.Entities.Enums;

namespace ValidandoSalario1.Entities
{
    class Worker
    {
        // Propriedade / atributos
        public string Name { get; set; }
        public WorkerLevel Level { get; set; }
        public double BaseSalary { get; set; }
        public Departament Departament { get; set; }

        // Foi criado a list para os contratos realizados
        public List<HourContract> Contracts { get; set; } = new List<HourContract>();

        // Contrutores
        public Worker()
        {

        }
        // Contrutores
        public Worker(string name, WorkerLevel level, double baseSalary, Departament departament)
        {
            Name = name;
            Level = level;
            BaseSalary = baseSalary;
            Departament = departament;
        }

        // Esse comando esta adicionando dados a lista criada
        public void AddContract(HourContract contract)
        {
            Contracts.Add(contract);
        }

        // esse comando esta removendo os dados da lista
        public void RemoveContract(HourContract contract)
        {
            Contracts.Remove(contract);
        }

        //  Percorrendo os contratos na lista de contratos para validar se é do mes / ano solicitado

        public double Income(int year, int month)
        {
            // ja foi adicionado o salario base, pois sempre vai ter o base do mes
            double sum = BaseSalary;

            //  Percorrendo os contratos na lista de contratos para validar se é do mes / ano solicitado

            foreach (HourContract contract in Contracts)
            {
                if(contract.Date.Year == year && contract.Date.Month == month)
                {
                    sum += contract.TotalValue();
                }
            }
            return sum;
        }

    }
}
