﻿
namespace ValidandoSalario1.Entities
{
    class Departament
    {
        public string Name { get; set; }

        // Propriedade / atributos
        public Departament()
        {
        }

        // Construtor 
        public Departament(string name)
        {
            Name = name;
        }

    }
}
