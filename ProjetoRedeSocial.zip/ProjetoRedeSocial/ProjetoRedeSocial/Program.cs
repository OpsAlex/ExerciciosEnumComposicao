﻿using System;
using ProjetoRedeSocial.Entities;

namespace ProjetoRedeSocial
{
    class Program
    {
        static void Main(string[] args)
        {
            // Exercicio de String Builder. Testando. // Segue o Case em anexo.

            // ESTANCIANDO
            Comment c1 = new Comment("Have a nice trip!");
            Comment c2 = new Comment("Wow that's awesome!");
            Post p1 = new Post(DateTime.Parse("21/06/2018 13:05:44"),
                "Treveling to New Zealand",
                "I'm goind to visit this wonderful country!",
                12
                );
            // Adicionando os comentarios a qual esta vindo a classe Comment
            p1.AddComment(c1);
            p1.AddComment(c2);

            Comment c3 = new Comment("Good Night ");
            Comment c4 = new Comment("May the Force be with you");
            Post p2 = new Post(
                DateTime.Parse("28/07/2018 23:14:19"),
                "Good Night guys",
                "See you tomorrow",
                5
                );

            // Adicionando os posts a qual esta vindo a classe Post

            p2.AddComment(c3);
            p2.AddComment(c4);

            // exibindo
            Console.WriteLine(p1);
            Console.WriteLine(p2);
                


        }
    }
}
