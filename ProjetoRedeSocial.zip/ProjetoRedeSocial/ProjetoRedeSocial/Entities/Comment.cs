﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetoRedeSocial.Entities
{
    class Comment
    {
        // criando propriedades
        public string Text { get; set; }

        // criando construtores
        public Comment()
        {

        }

        public Comment(string text)
        {
            Text = text;
        }
    }
}
