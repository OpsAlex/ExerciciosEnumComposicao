﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExercicioPolimorfismo.Entities
{
    class OutsourcedEmploye : Employe
    {
        public double AdditionalCharge { get; set; }

        public OutsourcedEmploye ()
        {

        }

        public OutsourcedEmploye(string name, int hours, double valuePerHour, double additionalCharge) : base(name, hours, valuePerHour)
        {
            AdditionalCharge = additionalCharge;
        }
        // reaproveitando a função pagamento e acrescentando um valor adicional
        public override double Payment()
        {
            return base.Payment() + 1.1 * AdditionalCharge;
        }
    }
}
