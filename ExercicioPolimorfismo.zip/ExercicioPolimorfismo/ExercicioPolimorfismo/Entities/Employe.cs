﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExercicioPolimorfismo.Entities
{
    class Employe
    {
        public string Name { get; set; }
        public int Hours { get; set; }
        public double ValuePerHour { get; set; }

        public Employe()
        {

        }

        public Employe(string name, int hours, double valuePerHour)
        {
            Name = name;
            Hours = hours;
            ValuePerHour = valuePerHour;
        }
        // Criando a função pagamento.
        public virtual double Payment()
        {
            return Hours * ValuePerHour;
        }
    }
}
