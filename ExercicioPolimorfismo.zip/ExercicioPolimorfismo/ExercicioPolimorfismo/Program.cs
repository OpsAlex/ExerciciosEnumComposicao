﻿using System;
using System.Collections.Generic;
using ExercicioPolimorfismo.Entities;
using System.Globalization;

namespace ExercicioPolimorfismo
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employe> list = new List<Employe>();
            
            Console.Write("Enter the number of employees: ");
            int n = int.Parse(Console.ReadLine());

            for (int i = 1; i < n; i++)
            {
                Console.WriteLine($"Employee #{i} data:");
                Console.Write("Outsourced (y/n)? ");
                char ch = char.Parse(Console.ReadLine());
                Console.WriteLine("Name: ");
                string name = Console.ReadLine();
                Console.WriteLine("Hours: ");
                int hours = int.Parse(Console.ReadLine());
                Console.WriteLine("Value per hour: ");
                double valuePerHour = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
                if(ch == 'y')
                {
                    Console.WriteLine("Additional Charge: ");
                    double additionalCharge = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
                    list.Add(new OutsourcedEmploye(name, hours, valuePerHour, additionalCharge));

                }
                else
                {
                    list.Add(new Employe(name, hours, valuePerHour));
                }

                Console.WriteLine("\nPayments: ");
                foreach (Employe emp in list)
                {
                    Console.WriteLine(emp.Name + "- $" + emp.Payment().ToString("F2", CultureInfo.InvariantCulture));
                }

            }

        }
    }
}
