﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExercicioEnumeComposicao.Entites.Enum
{

    // Criando as enumerações
    enum OrderStatus : int { 
    
        Pending_Payment = 0,
        Processing = 1,
        Shipped = 1,
        Delivered = 3
    }
}
