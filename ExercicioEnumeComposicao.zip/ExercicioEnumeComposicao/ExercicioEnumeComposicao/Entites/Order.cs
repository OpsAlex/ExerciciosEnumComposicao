﻿using System;
using System.Collections.Generic;
using System.Text;
using ExercicioEnumeComposicao.Entites.Enum;
using System.Globalization;

namespace ExercicioEnumeComposicao.Entites
{
    class Order
    {
        // Propriedades
        public DateTime Moment { get; set; }
        public OrderStatus Status { get; set; }
        public Client Client { get; set; }
        // Criando a lista de Pedidos
        public List<OrderItem> Pedidos { get; set; } = new List<OrderItem>();

        // criando o construtor
        public Order()
        {
        }

        public Order(DateTime moment, OrderStatus status, Client client)
        {
            Moment = moment;
            Status = status;
            Client = client;
        }

        // Adicionando pedidos
        public void AddItem(OrderItem item)
        {
            Pedidos.Add(item);
        }

        // Removendo pedidos

        public void RemoveItem(OrderItem item)
        {
            Pedidos.Remove(item);
        }

        // Fazendo o calculo do total. O foreach é para adicionar o subtotal na variavel sum para apresentar o total
        public double Total()
        {
            double sum = 0.0;
            foreach (OrderItem item in Pedidos)
            {
                sum += item.SubTotal();
            }
            return sum;
        }

        
        public override string ToString()
        {
            // Estamos usando o STRING BUILDER para ter uma melhor performace no programa e evitar repetições de strings
            StringBuilder sb = new StringBuilder();

            // ApreendLine vau adicionar o texto escrito e colocar uma quebra de linha no final
            sb.AppendLine("Order moment: " + Moment.ToString("dd/MM/yyyy HH:mm:ss"));
            sb.AppendLine("Order status: " + Status);
            sb.AppendLine("Client: " + Client);
            sb.AppendLine("Order items:");
            foreach (OrderItem item in Pedidos)
            {
                sb.AppendLine(item.ToString());
            }
            sb.AppendLine("Total price: " + Total().ToString("F2", CultureInfo.InvariantCulture));
            return sb.ToString();
        }


    }
}
