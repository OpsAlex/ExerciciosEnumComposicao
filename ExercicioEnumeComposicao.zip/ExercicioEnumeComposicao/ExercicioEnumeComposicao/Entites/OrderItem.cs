﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

namespace ExercicioEnumeComposicao.Entites
{
    class OrderItem
    {
        // Criando as propriedades
        public int Quantity { get; set; }
        public double Price { get; set; }
        public Product Product { get; set; }

        
        // Criando os Construtores
        public OrderItem()
        {
        }
        // Criando os Construtores
        public OrderItem(int quantity, double price, Product product)
        {
            Quantity = quantity;
            Price = price;
            Product = product;
        }
        // Criando o subtotal
        public double SubTotal()
        {
            return Price * Quantity;
        }


        // Criando o override para organizar as strings e formatar o modo de exibição
        public override string ToString()
        {
            return Product.Name
                + ", $"
                + Price.ToString("F2", CultureInfo.InvariantCulture)
                + ", Quantity: "
                + Quantity
                + ", Subtotal: $"
                + SubTotal().ToString("F2", CultureInfo.InvariantCulture);
        }

    }
}
